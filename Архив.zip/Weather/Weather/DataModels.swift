//
//  DataModels.swift
//  Weather
//
//  Created by Семенова Слепцова ИСИП 20 on 21.03.2022.
//

import Foundation
struct Weather: Codable {
    var id: Int
    var main: String
    var description: String
    var icon: String
}
struct Main: Codable {
    var temp: Double = 0.0
    var preasure: Int = 0
    var humidity: Int = 0
}
struct WeatherData: Codable {
    var weather: [Weather] = []
    var main: Main = Main()
    var name: String = ""
}
