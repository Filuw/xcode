
import UIKit
import CoreLocation

class ViewController: UIViewController {

    @IBOutlet weak var cityNameLabel: UILabel!
    @IBOutlet weak var countryNameLabel: UILabel!
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet var conditionLabel: UILabel!
    @IBOutlet weak var cityTempLabel: UILabel!
    @IBOutlet weak var inputCityName: UITextField!
    
    @IBAction func showCityNameAction(_ sender: Any)
    {
        let urlString = "https://api.weatherapi.com/v1/current.json?key=9811b2796144486081315932221603&q=\(inputCityName.text!)"
        let url = URL(string: urlString)
        let session = URLSession(configuration: .default)
        let task = session.dataTask(with: url!) { data, response, error in
            if let data = data{
                self.parseJSON(withData: data)
            }
        }
        task.resume()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let colorOne = UIColor (red: 255, green: 193, blue: 192, alpha: 1.0)
        let colorTwo = UIColor (red: 198, green: 129, blue: 141, alpha: 1.0)
        let gradient = CAGradientLayer()
        gradient.frame = self.view.bounds
        gradient.colors = [colorOne.cgColor, colorTwo.cgColor]
        self.view.layer.insertSublayer(gradient, at: 0)
    }
    
    func parseJSON(withData data: Data) {
        let decoder = JSONDecoder()
        do{
            let apiItem = try decoder.decode(Welcome.self, from: data)
            
            cityNameLabel.text = apiItem.location.name
            cityTempLabel.text = String(apiItem.current.tempC)
            countryNameLabel.text = apiItem.location.country
            conditionLabel.text = apiItem.current.condition.text
            dayLabel.text = String(apiItem.location.localtime)
        } catch
            let error as NSError {
            print(error.localizedDescription)
        }
    }
}
