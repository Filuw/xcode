//
//  secure.swift
//  Weater
//
//  Created by Семенова Слепцова ИСИП 20 on 12.03.2022.
//

import Foundation

let apiKey = "9811b2796144486081315932221603"
