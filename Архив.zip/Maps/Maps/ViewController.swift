//
//  ViewController.swift
//  Maps
//
//  Created by Семенова Слепцова ИСИП 20 on 28.03.2022.
//

import UIKit
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    @IBOutlet var mapView: MKMapView!
    
    // Переменные для создания маршрута
    var itemMapFirst: MKMapItem!
    var itemMapSecond: MKMapItem!
    
    // для работы с картой создается manager
    let manager: CLLocationManager = {
        let locationManager = CLLocationManager() // получение местоположения
        locationManager.activityType = .fitness // точно определяет местоположение
        locationManager.desiredAccuracy = kCLLocationAccuracyBest //
        locationManager.distanceFilter = 1 // фильтр дистанции
        locationManager.showsBackgroundLocationIndicator = true // отобразить индикатор на карте
        locationManager.pausesLocationUpdatesAutomatically = true // отображение обновления
        return locationManager
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        manager.delegate = self
        authorization()
        pinPosition()
    }
    
    func pinPosition() {
        let arrayLet = [62.03, 50.45]
        let arrayLon = [129.73, 30.52]
        for number in 0..<arrayLet.count {
            let point = MKPointAnnotation()
            point.title = "My point"
            point.coordinate = CLLocationCoordinate2D(latitude: arrayLet[number], longitude: arrayLon[number])
            mapView.addAnnotation(point)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // отображение координат с помощью цикла
        for location in locations {
            print(location.coordinate.latitude)
            print(location.coordinate.longitude)
            itemMapFirst = MKMapItem(placemark: MKPlacemark(coordinate: location.coordinate))
        }
    }
    
    // функция фвторизации
    func authorization () {
        // Проверка на разрешение использования местоположения (ALWAYS - всегда, INUSE - когда приложения открыто)
        if CLLocationManager.authorizationStatus() == .authorizedAlways || CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            mapView.showsUserLocation = true // отобразить на карте текущее местоположение пользователя
        } else {
            manager.requestWhenInUseAuthorization() // запрос на использование местоположения пользователя
        }
    }
    
    func calculayeRoute() {
        let request = MKDirections.Request()
        request.source = itemMapFirst
        request.destination = itemMapSecond
        request.requestsAlternateRoutes = true
        request.transportType = .walking
        let direction = MKDirections(request: request)
        direction.calculate {(response, error) in
            guard let directionResponse = response else {return}
            let route = directionResponse.routes[0]
            self.mapView.addOverlay(route.polyline, level: .aboveRoads)
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let render = MKPolygonRenderer(overlay: overlay)
        render.lineWidth = 5
        render.strokeColor = .red
        return render
    }
}
