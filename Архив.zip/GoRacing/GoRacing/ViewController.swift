//
//  ViewController.swift
//  GoRacing
//
//  Created by Семенова Слепцова ИСИП 20 on 05.03.2022.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var pcCar: UIImageView!
    @IBOutlet weak var userCar: UIImageView!
    @IBOutlet weak var resultlabel: UILabel!
    @IBOutlet weak var semaforlabel: UILabel!
    @IBOutlet weak var lineFinish: UIImageView!
    
    var stateSemafor: Int = 1
    var timerGame: Timer!
    var timerPC: Timer!
    
    @objc func pcDrive() {
        if stateSemafor == 2 {
            pcCar.center.x += 10
        }
        if pcCar.center.x > lineFinish.center.x {
            resultlabel.isHighlighted = false
            resultlabel.text = "YOU LOSE!"
            resultlabel.textColor = .red
            timerPC.invalidate()
            timerGame.invalidate()
        }
    }
    
    @objc func intervalTimer() {
        stateSemafor += 1
        if stateSemafor > 2 {
            stateSemafor = 1
        }
        switch stateSemafor {
        case 1:
            semaforlabel.text = "STOP"
            semaforlabel.textColor = .red
        case 2:
            semaforlabel.text = "DRIVE"
            semaforlabel.textColor = .green
        default:
            break
        }
    }
    
    @IBAction func startGame(_ sender: UIButton) {
        semaforlabel.isHidden = false
        
        Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(intervalTimer), userInfo: nil, repeats: true)
        timerPC = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(pcDrive), userInfo: nil, repeats: true)
        timerGame = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector:
            #selector(pcDrive), userInfo: nil, repeats: true)
    }
    
    @IBAction func driveGame(_ sender: UIButton) {
        if stateSemafor == 2 {
            userCar.center.x += 10
        } else if stateSemafor == 1 {
            userCar.center.x -= 10
        }
        if userCar.center.x > lineFinish.center.x {
            resultlabel.isHidden = false
            resultlabel.text = "YOU WIN!"
            resultlabel.textColor = .green
            timerPC.invalidate()
            timerGame.invalidate()
        }
    }
}
