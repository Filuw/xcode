//
//  ViewController.swift
//  Calculator2
//
//  Created by Семенова Слепцова ИСИП 20 on 02.03.2022.
//

import UIKit
class ViewController: UIViewController {
    
    @IBOutlet weak var min: UIButton!
    @IBOutlet weak var ses: UIButton!
    @IBOutlet weak var pat: UIButton!
    @IBOutlet weak var chet: UIButton!
    @IBOutlet weak var ym: UIButton!
    @IBOutlet weak var dev: UIButton!
    @IBOutlet weak var vos: UIButton!
    @IBOutlet weak var sem: UIButton!
    @IBOutlet weak var del: UIButton!
    @IBOutlet weak var od: UIButton!
    @IBOutlet weak var dv: UIButton!
    @IBOutlet weak var tr: UIButton!
    @IBOutlet weak var pl: UIButton!
    @IBOutlet weak var rav: UIButton!
    
    
    @IBOutlet weak var buttonAC: UIButton!
    @IBOutlet weak var buttonZero: UIButton!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var buttonChangeResultLabel:
        UIStepper!
    @IBOutlet weak var buttons: UIStackView!
    
    
    var numberOne = ""
    var numberTwo = ""
    var operand = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buttonAC.layer.cornerRadius = 36
        buttonZero.layer.cornerRadius = 36
        del.layer.cornerRadius = 36
        sem.layer.cornerRadius = 36
        vos.layer.cornerRadius = 36
        dev.layer.cornerRadius = 36
        ym.layer.cornerRadius = 36
        chet.layer.cornerRadius = 36
        pat.layer.cornerRadius = 36
        ses.layer.cornerRadius = 36
        min.layer.cornerRadius = 36
        od.layer.cornerRadius = 36
        dv.layer.cornerRadius = 36
        tr.layer.cornerRadius = 36
        pl.layer.cornerRadius = 36
        rav.layer.cornerRadius = 36
        
    }
    @IBAction func inputNumber(_ sender: UIButton) {
        if operand.isEmpty {
            numberOne = numberOne +
                (sender.titleLabel?.text)!
            resultLabel.text = numberOne
        }
        else
        {
            numberTwo = numberTwo +
                (sender.titleLabel!.text)!
            resultLabel.text = numberTwo
        }
    }
    
    @IBAction func inputOperand(_ sender: UIButton) {
        operand = sender.titleLabel?.text as!
            String
    }
    
    @IBAction func clearAction(_ sender: UIButton) {
        numberTwo = ""
        numberOne = ""
        operand = ""
        resultLabel.text = "0"
    }
    
    @IBAction func resultAction(_ sender: UIButton) {
        var result = 0.0
        switch operand {
        case "/":
            result = Double (numberOne)! /
                Double(numberTwo)!
        case "+":
            result = Double (numberOne)! +
                Double(numberTwo)!
        case "-":
            result = Double (numberOne)! -
                Double(numberTwo)!
        case "*":
            result = Double (numberOne)! *
                Double(numberTwo)!
        default:
            break
        }
        if result.truncatingRemainder(dividingBy: 1.0)
            == 0.0 {
            resultLabel.text = String(Int(result))
        }
        else
        {
            resultLabel.text = String(result)
        }
    }
    
    @IBAction func changeResultLabel(_ sender:
        UIStepper) {
        
        let font = resultLabel.font?.fontName
        let fontSize = CGFloat(sender.value)
        
        resultLabel.font = UIFont(name: font!, size:
            fontSize)
    }
    
    @IBAction func hiddenButtons(_ sender: Any) {
        buttons.isHidden = !buttons.isHidden
        buttonChangeResultLabel.isHidden = !buttonChangeResultLabel.isHidden
    }
}

