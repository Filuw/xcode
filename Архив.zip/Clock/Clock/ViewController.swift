//
//  ViewController.swift
//  Clock
//
//  Created by Семенова Слепцова ИСИП 20 on 01.04.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

