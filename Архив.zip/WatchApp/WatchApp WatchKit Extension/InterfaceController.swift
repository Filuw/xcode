//
//  InterfaceController.swift
//  WatchApp WatchKit Extension
//
//  Created by Семенова Слепцова ИСИП 20 on 01.04.2022.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    @IBOutlet var cityNameLabel: WKInterfaceTextField!
    @IBOutlet var weatherDescriptionLabel: WKInterfaceTextField!
    @IBOutlet var temperatureLabel: WKInterfaceTextField!
    @IBOutlet var weatherIconImageView: WKInterfaceImage!

    override func awake(withContext context: Any?) {
        super .awake(withContext: context)
        // Configure interface objects here.
    }
    
    override func willActivate() {
        super.willActivate()
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        super.didDeactivate()
        // This method is called when watch view controller is no longer visible
    }
}
